<?php
        $conn=mysqli_connect("localhost","root","","KKK");
        if($conn===false) {
            die("ERROR:could not connect"
            .mysqli_connect_error());
        } 
        $team_name= $_REQUEST['team_name'];
        $sql= "DELETE FROM team WHERE team_name like '$team_name'";
        if(mysqli_query($conn,$sql)){
            echo "data saved successfully";
        }else{
            echo "ERROR "
            .mysqli_error($conn);
        }
        ?>