<?php
$host='localhost';
$user='root';
$password='';
$dbname='KKK';
$conn = mysqli_connect($host,$user,$password,$dbname);
if(!$conn)
{
    die('Could not connect'.mysqli_connect_error());
}
echo'connected successfully<br/>';
$sql= "create table stats(p_id int,t_name varchar(30) ,runs int,avg varchar(10),wkts int,eco varchar(10),foreign key(p_id) references player(player_id),foreign key(t_name) references team(team_name))";
if(mysqli_query($conn, $sql)){ 
    echo "Table stats created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
$sql= "create table points_table(t_name varchar(30),wins int,losses int,draw int,pts int,foreign key(t_name) references team(team_name))";
if(mysqli_query($conn, $sql)){ 
    echo "Table points_table created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
 $sql= "create table support_staff(s_name varchar(30),t_name varchar(30),role varchar(30),salary real,foreign key(t_name) references team(team_name))";
 if(mysqli_query($conn, $sql)){ 
    echo "Table support_staff created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
  mysqli_close($conn);
  ?>