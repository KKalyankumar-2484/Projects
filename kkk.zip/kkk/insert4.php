<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "KKK");
		
	
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
	
		$player_id = $_REQUEST['p_id'];
		$team_name = $_REQUEST['t_name'];
		$runs = $_REQUEST['runs'];
		$avg= $_REQUEST['avg'];
		$wkts = $_REQUEST['wkts'];
        $eco = $_REQUEST['eco'];
		
		
		$sql = "INSERT INTO stats VALUES ('$player_id','$team_name',
			'$runs','$avg','$wkts','$eco')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully.</h3>";

			echo nl2br("\n$player_id\n $team_name\n "
				. "$runs\n $avg\n $wkts\n $eco");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
