<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update page</title>
    <link rel="stylesheet" href="insert.css">
</head>
<body>
   
    <center>
    <form action="update1.php" method="post">
    <p>
            <label for="t_name">TEAM NAME YOU WANT TO UPDATE:</label>
            <input type="text" name="t_name" id="t_name">
        </p>
        <p>
            <label for="wins">UPDATE WINS:</label>
            <input type="text" name="wins" id="wins">
        </p>
       
        <p>
            <label for="losses">UPDATE LOSSES:</label>
            <input type="text" name="losses" id="losses">
        </p>
        <p>
            <label for="draw">UPDATE DRAW:</label>
            <input type="text" name="draw" id="draw">
        </p>
       
        <p>
            <label for="pts">UPDATE POINTS:</label>
            <input type="text" name="pts" id="pts">
        </p>
       
        <input type="submit" value="Submit">
        </form>
     
             <p><a href="points.php"><button>CLICK</button></a> HERE TO VIEW THE POINTS TABLE.</p>
        </center>
        <div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<div class="content">
<h1> POINTS TABLE UPDATE</h1>
</body>
</html>