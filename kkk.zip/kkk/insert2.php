<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "KKK");
		
	
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
	
		$player_id = $_REQUEST['player_id'];
		$player_name = $_REQUEST['pname'];
		$role = $_REQUEST['role'];
		$salary= $_REQUEST['salary'];
		$captain_id = $_REQUEST['captain_id'];
        $team_name = $_REQUEST['team_name'];
		
		
		$sql = "INSERT INTO player VALUES ('$player_id','$player_name',
			'$role','$salary','$captain_id','$team_name')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully.</h3>";

			echo nl2br("\n$player_id \n$player_name\n $role\n "
				. "$salary\n $captain_id\n $team_name");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
