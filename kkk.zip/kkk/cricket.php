<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cricket tournament</title>
    <link rel="stylesheet" href="user.css">
    <script type="text/javascript">
    function goToNewPage()
    {
        var url = document.getElementById('list').value;
        if(url != 'none') {
            window.location = url;
        }
    }
</script>
</head>
<body>
    <div class="cric">
        <h></h1>
    
    <nav class="navbar">
        <ul>
        <li><a href="#"><p><a href="team.php">TEAM</a></p></a></li>
            <li><a href="#"><p><a href="points.php">POINTS TABLE</a></p></a></li>
            <li><a href="#"><p><a href="player.php">PLAYER</a></p></a></li>
            <li><a href="#"><p><a href="stats.php">STATS</a></p></a></li>
            <li><a href="#"><p><a href="sstaff.php">SUPPORT STAFF</a></p></a></li>
        </ul>
       <p><a href="View.php"> <img src="https://pbs.twimg.com/profile_images/787026427635916801/e14pu4sR_400x400.jpg" alt="profile"></a></p>
    </nav>

<div>
    <h2>
     
    </h2>
</div>
</div>
</body>
</html>