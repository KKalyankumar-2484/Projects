<!DOCTYPE html>
<html>

<head>
	<title>Update Page </title>
</head>

<body>
	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "KKK");

		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
	
		$team_name = $_REQUEST['t_name'];
        $wins = $_REQUEST['wins'];
		$losses = $_REQUEST['losses'];
		$draw= $_REQUEST['draw'];
		$pts= $_REQUEST['pts'];
	
		
		$sql = "Update points_table SET wins='$wins',losses='$losses',draw='$draw',pts='$pts' WHERE  t_name='$team_name' ";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully.</h3>";

			echo nl2br("\n$team_name\n $wins\n "
				. "$losses\n $draw\n $pts\n");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
