<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>delete page</title>
    <link href="delete.css" rel="stylesheet">


</head>
<body>
    
    <div class="hero"> 

    <center>
    <form action="delete5.php" method="post">
        <p>
            <label for="p_id">player_id:</label>
            <input type="text"  name="p_id" id="p_id">
        </p>
       
        <input type="submit" value="Submit">
        </form>
        
         <p><a href="stats.php"><button>CLICK</button></a> HERE TO VIEW THE STATS TABLE.</p>
        </center>
            <div class="hero__title">DELETE STATS OF THE PLAYERS</div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
          </div>
  
        
            
</body>
</html>