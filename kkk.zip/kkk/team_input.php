<form class="form-horizontal" role="form" method="post" action="insert1.php">
	<div class="form-group">
		<label for="team_name" class="col-sm-2 control-label">TEAM Name</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="team_name" name="team_name" placeholder="Team name" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="o_name" class="col-sm-2 control-label">OWNER NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="o_name" name="o_name" placeholder="Owner name" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="trophies" class="col-sm-2 control-label">TROPHIES</label>
		<div class="col-sm-10">
		<input type="text" class="form-control" id="trophies" name="trophies" placeholder="Trophies" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="win_per" class="col-sm-2 control-label">WIN PERCENTAGE</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="win_per" name="win_per" placeholder="Win percentage">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<input id="submit" name="submit" type="submit" value="Send" class="btn btn-primary">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<! Will be used to display an alert to the user>
		</div>
	</div>
</form>