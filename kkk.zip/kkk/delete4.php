<?php
        $conn=mysqli_connect("localhost","root","","KKK");
        if($conn===false) {
            die("ERROR:could not connect"
            .mysqli_connect_error());
        } 
        $staff_name= $_REQUEST['s_name'];
        $sql= "DELETE FROM support_staff WHERE s_name='$staff_name'";
        if(mysqli_query($conn,$sql)){
            echo "<h3>it is deleted </h3>";
        }else{
            echo "ERROR"
            .mysqli_error($conn);
        }
        ?>