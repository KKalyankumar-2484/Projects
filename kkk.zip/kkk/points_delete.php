<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>delete page</title>
    <link href="delete.css" rel="stylesheet">
</head>
<body>
<div class="hero"> 
    <center>
    <form action="delete3.php" method="post">
        <p>
            <label for="t_name">team_name:</label>
            <input type="text"  name="t_name" id="t_name">
        </p>
       
        <input type="submit" value="Submit">
        </form>
       
         <p><a href="player.php"><button>CLICK</button></a>HERE TO VIEW THE POINTS TABLE.</p>
        </center>
       
            <div class="hero__title">DELETE TEAM FROM POINTS TABLE</div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
            <div class="cube"></div>
          </div>
</body>
</html>