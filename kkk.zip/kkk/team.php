<!DOCTYPE html>
<html lang="en">
<head>
  <title>TEAM DETAILS</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.5/css/bootstrap.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.5/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="team.css">
</head>
<body>
        <h1>TEAM DETAILS</h1>
		<center>
  <?php
  

  $link = mysqli_connect("localhost", "root", "", "KKK");

  if($link === false){
      die("ERROR: Could not connect. " . mysqli_connect_error());
  }
  echo "<br>";
  
  
  $sql = "SELECT * FROM team order by win_per desc ";
  $result = $link->query($sql);
		
	echo "<div class='container'>";
		echo "<div class='row-fluid'>";
		
			echo "<div class='col-xs-6'>";
			echo "<div class='table-responsive'>";
			echo "<center>";
				echo "<table class='table table-hover table-inverse'>";
				
				echo "<tr>";
				echo "<th>TEAM NAME</th>";
				echo "<th>OWNER NAME</th>";
				echo "<th>TROPHIES</th>";
                echo "<th>WIN PERCENTAGE</th>";
				echo "</tr>";
		  
				if ($result->num_rows > 0) {
					
					while($row = $result->fetch_assoc()) {
							
						echo "<tr>";
						echo "<td>" . $row["team_name"] . "</td>";
						echo "<td>" . $row["o_name"] . "</td>";
						echo "<td>" . $row["trophies"] . "</td>";
                        echo "<td>" . $row["win_per"] . "</td>";
						echo "</tr>";			
					}
				} else {
					echo "0 results";
				}
				
				echo "</table>";
				echo "</center>";
                echo "</div>";

      
                mysqli_close($link);
                ?>
             </center>
			</body>
			</html>