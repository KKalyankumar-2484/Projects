<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>staff insert page</title>
    <link rel="stylesheet" href="insert.css">
</head>
<body >
   
    <center>
    <form class="form-horizontal" role="form" method="post" action="insert3.php">
	<div class="form-group">
		<label for="s_name" class="col-sm-2 control-label">STAFF NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="s_name" name="s_name" placeholder="eg RAM" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="t_name" class="col-sm-2 control-label">TEAM NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="t_name" name="t_name" placeholder="eg CSK" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="role" class="col-sm-2 control-label">ROLE</label>
		<div class="col-sm-10">
		<input type="text" class="form-control" id="role" name="role" placeholder="eg physio" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="salary" class="col-sm-2 control-label">SALARY</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="salary" name="salary" placeholder="eg 600000">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<input id="submit" name="submit" type="submit" value="SUBMIT" class="btn btn-primary">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<! Will be used to display an alert to the user>
		</div>
	</div>
</form>
     
             <p><a href="sstaff.php"><button>CLICK</button></a>HERE TO VIEW THE SUPPORT STAFF TABLE.</p>
        </center>
        <div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<div class="content">
<h1>INSERT SUPPORT STAFF INFO</h1>
</body>
</html>