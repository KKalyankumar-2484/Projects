<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>delete page</title>
    <link href="delete.css" rel="stylesheet">
</head>
<body>
<div class="hero"> 
    <center>
    <form action="delete4.php" method="post">
        <p>
            <label for="s_name">staff_name:</label>
            <input type="text"  name="s_name" id="s_name">
        </p>
       
        <input type="submit" value="Submit">
        </form>
        
         <p><a href="sstaff.php"><button>CLICK</button></a> HERE TO VIEW THE SUPPORT STAFF TABLE.</p>
        </center>
       
        <div class="hero"> 
  <div class="hero__title">SUPPORT STAFF DELETION</div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
</div>
</body>
</html>