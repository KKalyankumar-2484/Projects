<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>insert page</title>
    <link rel="stylesheet" href="insert.css">
</head>
<body>
   
    <center>
    <form class="form-horizontal" role="form" method="post" action="insert1.php">
	<div class="form-group">
		<label for="team_name" class="col-sm-2 control-label">TEAM Name</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="team_name" name="team_name" placeholder="eg CSK" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="o_name" class="col-sm-2 control-label">OWNER NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="o_name" name="o_name" placeholder="eg Indian Cements" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="trophies" class="col-sm-2 control-label">TROPHIES</label>
		<div class="col-sm-10">
		<input type="text" class="form-control" id="trophies" name="trophies" placeholder="eg 4" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="win_per" class="col-sm-2 control-label">WIN PERCENTAGE</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="win_per" name="win_per" placeholder="eg 58">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<input id="submit" name="submit" type="submit" value="SUBMIT" class="btn btn-primary">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<! Will be used to display an alert to the user>
		</div>
	</div>
</form>
             <p><a href="team.php"><button>CLICK</button></a>HERE TO VIEW THE TEAM TABLE.</p>
             </center>
             <div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<div class="content">
  <h1>INSERT NEW TEAMS</h1>
</div>
</body>
</html>