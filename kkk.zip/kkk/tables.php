<?php
$host='localhost';
$user='root';
$password='';
$dbname='CTC';
$conn = mysqli_connect($host,$user,$password,$dbname);
if(!$conn)
{
    die('Could not connect'.mysqli_connect_error());
}
echo'connected successfully<br/>';
 $sql = "create table team(team_name varchar(30) NOT NULL,o_name varchar(30) NOT NULL,trophies int,win_per real,  primary key(team_name))";
 if(mysqli_query($conn, $sql)){ 
   echo "Table team created successfully"; 
   }else{ 
   echo "Could not create table: ". mysqli_error($conn); 
   }
   
$sql = "create table player(player_id int primary key,pname varchar(30) NOT NULL,role varchar(10) NOT NULL,salary real,captain_id int,team_name varchar(30) NOT NULL)";
if(mysqli_query($conn, $sql)){ 
    echo "Table player created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
$sql= "create table stats(p_id int,t_name varchar(30) ,runs int,avg varchar(10),wkts int,eco varchar(10))";
if(mysqli_query($conn, $sql)){ 
    echo "Table stats created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
$sql= "create table points_table(t_name varchar(30),wins int,losses int,draw int,pts int)";
if(mysqli_query($conn, $sql)){ 
    echo "Table points_table created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
 $sql= "create table support_staff(s_name varchar(30),t_name varchar(30),role varchar(30),salary real)";
 if(mysqli_query($conn, $sql)){ 
    echo "Table support_staff created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
  mysqli_close($conn);
  ?>