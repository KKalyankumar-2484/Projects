<?php
        $conn=mysqli_connect("localhost","root","","KKK");
        if($conn===false) {
            die("ERROR:could not connect"
            .mysqli_connect_error());
        } 
        $player_id= $_REQUEST['p_id'];
        $sql= "DELETE FROM stats WHERE p_id=$player_id";
        if(mysqli_query($conn,$sql)){
            echo "<h3>it is deleted </h3>";
        }else{
            echo "ERROR"
            .mysqli_error($conn);
        }
        ?>