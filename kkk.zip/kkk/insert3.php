<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "KKK");

		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
	
		$staff_name = $_REQUEST['s_name'];
        $team_name = $_REQUEST['t_name'];
		$role = $_REQUEST['role'];
		$salary= $_REQUEST['salary'];
	
		
		$sql = "INSERT INTO support_staff VALUES ('$staff_name',
			'$team_name','$role','$salary')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully.</h3>";

			echo nl2br("\n$staff_name\n $team_name\n "
				. "$role\n $salary");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
