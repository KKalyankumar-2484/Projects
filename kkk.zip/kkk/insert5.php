<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "KKK");

		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
	
		$team_name = $_REQUEST['t_name'];
        $wins = $_REQUEST['wins'];
		$losses = $_REQUEST['losses'];
		$draw= $_REQUEST['draw'];
		$pts= $_REQUEST['pts'];
	
		
		$sql = "INSERT INTO points_table VALUES ('$team_name','$wins','$losses','$draw','$pts')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully.</h3>";

			echo nl2br("\n$team_name\n $wins\n "
				. "$losses\n $pts");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
