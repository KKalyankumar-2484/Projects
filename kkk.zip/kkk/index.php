<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cricket User Page</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Sriracha&display=swap');

    body {
      margin: 0;
      box-sizing: border-box;
    }

    /* CSS for header */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #f5f5f5;
    }

    .header .logo {
      font-size: 25px;
      font-family: 'Sriracha', cursive;
      color: #000;
      text-decoration: none;
      margin-left: 30px;
    }

    .nav-items {
      display: flex;
      justify-content: space-around;
      align-items: center;
      background-color: #f5f5f5;
      margin-right: 20px;
    }

    .nav-items a {
      text-decoration: none;
      color: #000;
      padding: 35px 20px;
    }

    /* CSS for main element */
    .intro {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 520px;
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.5) 100%), url("https://feeds.abplive.com/onecms/images/uploaded-images/2023/03/30/51b8290feee8be01e2767a5678e8581b1680183626765567_original.jpg?impolicy=abp_cdn&imwidth=650");
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }

    .intro h1 {
      font-family: sans-serif;
      font-size: 60px;
      color: #fff;
      font-weight: bold;
      text-transform: uppercase;
      margin: 0;
    }

    .intro p {
      font-size: 20px;
      color: #ede7e7;
      text-transform: uppercase;
      margin: 20px 0;
    }

    .intro button {
      background-color: #5edaf0;
      color: #1e0c17;
      padding: 10px 25px;
      border: none;
      border-radius: 5px;
      font-size: 20px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0px 0px 20px rgba(255, 255, 255, 0.4)
    }

    .achievements {
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 40px 80px;
    }

    .achievements .work {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 0 40px;
    }

    .achievements .work i {
      width: fit-content;
      font-size: 50px;
      color: #ad1a1a;
      border-radius: 50%;
      border: 2px solid #333333;
      padding: 12px;
    }

    .achievements .work .work-heading {
      font-size: 20px;
      color: #4d4b4a;
      text-transform: uppercase;
      margin: 10px 0;
    }

    .achievements .work .work-text {
      font-size: 15px;
      color: #10110f;
      margin: 10px 0;
    }

    .about-me {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 80px;
      border-top: 2px solid #ffffff;
    }

    .about-me img {
      width: 500px;
      max-width: 100%;
      height: auto;
      border-radius: 10px;
    }

    .about-me-text h2 {
      font-size: 30px;
      color: #f50707;
      text-transform: uppercase;
      margin: 0;
    }

    .about-me-text p {
      font-size: 15px;
      color: #6c2a62;
      margin: 10px 0;
    }

    /* CSS for footer */
    .footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #625ec9;
      padding: 40px 80px;
    }

    .footer .copy {
      color: #d7f30b;
    }

    .bottom-links {
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 40px 0;
    }

    .bottom-links .links {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 0 40px;
    }

    .bottom-links .links span {
      font-size: 20px;
      color: #f1f127;
      text-transform: uppercase;
      margin: 10px 0;
    }

    .bottom-links .links a {
      text-decoration: none;
      color: #f9f8f9;
      padding: 10px 20px;
    }
  </style>
</head>

<body>
  <header class="header">
    <i class="fas fa-users"></i>
    <a href="#" class="logo">CRICKET USER</a>
    <nav class="nav-items">
      <a href="#"><p><a href="team.php">TEAM</a></p></a>
      <a href="#"><p><a href="points.php">POINTSTABLE</a></p></a>
      <a href="#"><p><a href="player.php">PLAYER</a></p></a>
      <a href="#"><p><a href="stats.php">STATS</a></p></a>
      <a href="#"><p><a href="sstaff.php">STAFF</a></p></a>
    </nav>
  </header>
  <main>
    <div class="intro">
      <h1>CRICKET TOURNAMENT</h1>
      <p></p>
      <a href="#"><p><a href="learmore.html"><button>Learn More</button></a></p></a>
      
    </div>
    <div class="achievements">
      <div class="work">
        <i class="fas fa-users"></i>
        <p class="work-heading">MOST SUCCESSFULL TEAMS</p>
        <p class="work-text">CSK,MI,RCB are the most successfull teams in the history of this game with lot of fan following.CSK has won 4 trophies and has win percentage of 58.6, MI has won 5 trophies and has winning percentage of 56, RCB didn't won any but has lot of great performance </p>
      </div>
      <div class="work">
        <i class="fas fa-baseball-ball"></i>
        <p class="work-heading">BEST BOWLERS</p>
        <p class="work-text">Bhuvaneshwar,Irfan Pathan,DJ Bravo,Muthaimuralitharan,Lasith Mallinga are the most successfull bowlers in the league history</p>
      </div>
      <div class="work">
        <i class="fas fa-layer-group"></i>
        <p class="work-heading">BEST BATSMEN</p>
        <p class="work-text">Virat Kohli,Rohit Sharma,AB Devilers,MS Dhoni,Suresh Raina,David Warner,K Pollard are some of the greatest batsmen of the league</p>
      </div>
    </div>
    <div class="about-me">
      <div class="about-me-text">
        <h2>About This League</h2>
        <p>On 13 September 2007, on the back of India's victory at the 2007 T20 World Cup, BCCI announced a franchise-based Twenty20 cricket competition called Indian Premier League. The first season was slated to start in April 2008, in a "high-profile ceremony" in New Delhi. BCCI vice-president Lalit Modi, who spearheaded the IPL effort, spelled out the details of the tournament including its format, the prize money, franchise revenue system and squad composition rules. It was also revealed that the IPL would be run by a seven-man governing council composed of former India players and BCCI officials and that the top two teams of the IPL would qualify for that year's Champions League Twenty20. Modi also clarified that they had been working on the idea for two years and that the IPL was not started as a "knee-jerk reaction" to the ICL. The league's format was similar to that of the Premier League of England and the NBA in the United States.</p>
        
    </div>
     
    </div>
  </main>
  <footer class="footer">
    <div class="copy">&copy;2023 TOURNAMENT</div>
    <div class="bottom-links">
     
      <div class="links">
        <span>FOLLOW US ON</span>
        <a href="#"><i class="fab fa-facebook"></i>crickettourn@facebook</a>
        <a href="#"><i class="fab fa-twitter"></i>crictourn#01</a>
        <a href="#"><i class="fab fa-instagram"></i>crictourn@01</a>
      </div>
    </div>
  </footer>
</body>

</html>