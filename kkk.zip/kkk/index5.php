<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>insert page</title>
    <link rel="stylesheet" href="insert.css">
</head>
<body>
   
    <center>
    <form class="form-horizontal" role="form" method="post" action="insert5.php">
	<div class="form-group">
		<label for="t_name" class="col-sm-2 control-label">TEAM Name</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="t_name" name="t_name" placeholder="eg CSK" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="wins" class="col-sm-2 control-label">WINS</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="wins" name="wins" placeholder="eg 10" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="losses" class="col-sm-2 control-label">LOSSES</label>
		<div class="col-sm-10">
		<input type="text" class="form-control" id="losses" name="losses" placeholder="eg 4" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="draw" class="col-sm-2 control-label">DRAW</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="draw" name="draw" placeholder="eg 1">
		</div>
	</div>
    <div class="form-group"> 
		<label for="pts" class="col-sm-2 control-label">POINTS</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="pts" name="pts" placeholder="eg 20">
		</div>
	</div>    
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<input id="submit" name="submit" type="submit" value="SUBMIT" class="btn btn-primary">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<! Will be used to display an alert to the user>
		</div>
	</div>
</form>
     
             <p><a href="points.php"><button>CLICK</button></a> HERE TO VIEW THE POINTS TABLE.</p>
        </center>
        <div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<div class="content">
<h1>INSERT TEAMS INTO POINTS TABLE</h1>
</body>
</html>