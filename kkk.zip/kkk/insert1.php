<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

		$conn = mysqli_connect("localhost", "root", "", "KKK");
		
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$team_name = $_REQUEST['team_name'];
		$owner_name = $_REQUEST['o_name'];
		$trophies = $_REQUEST['trophies'];
		$win_percentage = $_REQUEST['win_per'];
		
		
		$sql = "INSERT INTO team VALUES ('$team_name',
			'$owner_name','$trophies','$win_percentage')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully.</h3>";
    
			echo nl2br("\n$team_name\n $owner_name\n "
				. "$trophies\n $win_percentage");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
