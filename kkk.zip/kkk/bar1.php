<?php

include_once("includes/db_connect.php");

?>

<html>

    <head>

        <!--chart js -->

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    </head>

    <body>
    <?php

$chkresults = mysqli_query($con,"SELECT Player AS subscriber_month, COUNT(*) AS subscriber_count FROM subscribers GROUP BY MONTH(subscribed_on)");    

?>

<script type="text/javascript">

google.charts.load('current', {'packages':['Bar']});

google.charts.setOnLoadCallback(drawChart);



function drawChart() {

  var data = google.visualization.arrayToDataTable([

     ['Month','Subscribers'],
     <?php     

        while($row=mysqli_fetch_assoc($chkresults)){            

           echo "['".$row["subscriber_month"]."',".$row["subscriber_count"]."],";

          }

         ?>

        ]);

        var options = {

          chart: {

            title: '',          

          },
          bars: 'vertical',

          vAxis: {format: 'decimal'},

          height: 300,

          colors: ['#d95f02']

        };

        var chart = new google.charts.Bar(document.getElementById('bar-graph-location'));

        chart.draw(data, google.charts.Bar.convertOptions(options));

      }

    </script>     
    <!--location where bar graph will be displayed-->

    <div id="bar-graph-location">

</div>

</body>

</html>