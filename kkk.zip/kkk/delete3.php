<?php
        $conn=mysqli_connect("localhost","root","","KKK");
        if($conn===false) {
            die("ERROR:could not connect"
            .mysqli_connect_error());
        } 
        $team_name= $_REQUEST['t_name'];
        $sql= "DELETE FROM points_table WHERE t_name='$team_name'";
        if(mysqli_query($conn,$sql)){
            echo "<h3>it is deleted </h3>";
        }else{
            echo "ERROR"
            .mysqli_error($conn);
        }
        ?>