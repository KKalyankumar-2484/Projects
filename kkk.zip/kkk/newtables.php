<?php
$host='localhost';
$user='root';
$password='';
$dbname='KKK';
$conn = mysqli_connect($host,$user,$password,$dbname);
if(!$conn)
{
    die('Could not connect'.mysqli_connect_error());
}
echo'connected successfully<br/>';
 $sql = "create table team(team_name varchar(30) NOT NULL,o_name varchar(30) NOT NULL,trophies int,win_per real,  primary key(team_name))";
 if(mysqli_query($conn, $sql)){ 
   echo "Table team created successfully"; 
   }else{ 
   echo "Could not create table: ". mysqli_error($conn); 
   }
   


  mysqli_close($conn);
  ?>