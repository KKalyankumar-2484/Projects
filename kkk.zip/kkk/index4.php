<!DOCTYPE html>
<html lang="en">
<head>
	<title>STORE stats INFO</title>
	<link rel="stylesheet" href="insert.css">
</head>
<body>
	<center>
		<h1>Storing Form data in Database</h1>
		<form class="form-horizontal" role="form" method="post" action="insert4.php">
	<div class="form-group">
		<label for="p_id" class="col-sm-2 control-label">PLAYER ID</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="p_id" name="p_id" placeholder="eg 07" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="t_name" class="col-sm-2 control-label">TEAM NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="t_name" name="t_name" placeholder="eg CSK" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="runs" class="col-sm-2 control-label">RUNS</label>
		<div class="col-sm-10">
		<input type="text" class="form-control" id="runs" name="runs" placeholder="eg 567" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="avg" class="col-sm-2 control-label">AVERAGE</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="avg" name="avg" placeholder="eg 46">
		</div>
	</div>
	
	<div class="form-group">
		<label for="wkts" class="col-sm-2 control-label">WICKETS</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="wkts" name="wkts" placeholder="eg 33" value="">
		</div>
	</div>	
	<div class="form-group">
		<label for="eco" class="col-sm-2 control-label">ECONOMY</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="eco" name="eco" placeholder="eg 7.9" value="">
		</div>
	</div>	
	
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<input id="submit" name="submit" type="submit" value="SUBMIT" class="btn btn-primary">
		</div>
	</div>	
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<! Will be used to display an alert to the user>
		</div>
	</div>
</form>
		<p><a href="stats.php"><button>CLICK</button></a>HERE TO VIEW THE STATS TABLE.</p>
	</center>
	<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<div class="content">
<h1>INSERT PLAYER STATS INFO</h1>
</body>
</html>
