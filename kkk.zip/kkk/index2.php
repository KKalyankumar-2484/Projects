<!DOCTYPE html>
<html lang="en">
<head>
	<title>STORE PLAYER INFO</title>
	<link rel="stylesheet" href="insert.css">
</head>
<body>
	<center>
		<h1>Storing Form data in Database</h1>
		<form class="form-horizontal" role="form" method="post" action="insert2.php">
	<div class="form-group">
		<label for="player_id" class="col-sm-2 control-label">PLAYER ID</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="player_id" name="player_id" placeholder="eg 07" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="pname" class="col-sm-2 control-label">PLAYER NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="pname" name="pname" placeholder="eg MS Dhoni" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="role" class="col-sm-2 control-label">ROLE</label>
		<div class="col-sm-10">
		<input type="text" class="form-control" id="role" name="role" placeholder="eg ALLROUNDER" value="">
		</div>
	</div>
	<div class="form-group">
		<label for="salary" class="col-sm-2 control-label">SALARY</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="salary" name="salary" placeholder="eg 150000000">
		</div>
	</div>
	
	<div class="form-group">
		<label for="captain_id" class="col-sm-2 control-label">CAPTAIN ID</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="captain_id" name="captain_id" placeholder="eg 07" value="">
		</div>
	</div>	
	<div class="form-group">
		<label for="team_name" class="col-sm-2 control-label">Team NAME</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="team_name" name="team_name" placeholder="eg CSK" value="">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<input id="submit" name="submit" type="submit" value="SUBMIT" class="btn btn-primary">
		</div>
	</div>	
	<div class="form-group">
		<div class="col-sm-10 col-sm-offset-2">
			<! Will be used to display an alert to the user>
		</div>
	</div>
</form>
		<p><a href="player.php"><button>CLICK</button></a>HERE TO VIEW THE PLAYER TABLE.</p>
	</center>
	<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<div class="content">
	<h1>INSERT PLAYERS INFO</h1>
</body>
</html>
