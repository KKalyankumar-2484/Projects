<?php
$host='localhost';
$user='root';
$password='';
$dbname='KKK';
$conn = mysqli_connect($host,$user,$password,$dbname);
if(!$conn)
{
    die('Could not connect'.mysqli_connect_error());
}
echo'connected successfully<br/>';
$sql = "create table player(player_id int primary key,pname varchar(30) NOT NULL,role varchar(10) NOT NULL,salary real,captain_id int,team_name varchar(30) NOT NULL,foreign key(team_name) references team(team_name))";
if(mysqli_query($conn, $sql)){ 
    echo "Table player created successfully"; 
    }else{ 
    echo "Could not create table: ". mysqli_error($conn); 
    }
    

  mysqli_close($conn);
  ?>